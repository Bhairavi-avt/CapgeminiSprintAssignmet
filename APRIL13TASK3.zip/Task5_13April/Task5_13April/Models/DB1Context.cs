﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace Task5_13April.Models
{
    public partial class DB1Context : DbContext
    {
        public DB1Context()
        {
        }

        public DB1Context(DbContextOptions<DB1Context> options)
            : base(options)
        {
        }

        public virtual DbSet<Accdet> Accdet { get; set; }
        public virtual DbSet<Coursedet> Coursedet { get; set; }
        public virtual DbSet<Dept> Dept { get; set; }
        public virtual DbSet<Employee> Employee { get; set; }
        public virtual DbSet<Person> Person { get; set; }
        public virtual DbSet<RegDet> RegDet { get; set; }
        public virtual DbSet<Staffdet> Staffdet { get; set; }
        public virtual DbSet<Student> Student { get; set; }
        public virtual DbSet<Studentdet> Studentdet { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Data Source=DESKTOP-3MAOMFA\\SQLEXPRESS;Database=DB1;Integrated Security=True");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Accdet>(entity =>
            {
                entity.HasKey(e => new { e.Accno, e.Regno })
                    .HasName("PK__accdet__B5F6313CB2AF4667");

                entity.ToTable("accdet");

                entity.Property(e => e.Accno).HasColumnName("accno");

                entity.Property(e => e.Regno).HasColumnName("regno");

                entity.Property(e => e.Ahname)
                    .HasColumnName("ahname")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Damount)
                    .HasColumnName("damount")
                    .HasColumnType("money");
            });

            modelBuilder.Entity<Coursedet>(entity =>
            {
                entity.HasKey(e => e.Cid)
                    .HasName("PK__Coursede__D837D05FA2F0EB31");

                entity.Property(e => e.Cid)
                    .HasColumnName("cid")
                    .ValueGeneratedNever();

                entity.Property(e => e.Cduration).HasColumnName("cduration");

                entity.Property(e => e.Cfee)
                    .HasColumnName("cfee")
                    .HasColumnType("money");

                entity.Property(e => e.Cname)
                    .HasColumnName("cname")
                    .HasMaxLength(40)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Dept>(entity =>
            {
                entity.HasKey(e => e.Did)
                    .HasName("PK__Dept__D877D2167515A516");

                entity.Property(e => e.Did)
                    .HasColumnName("did")
                    .ValueGeneratedNever();

                entity.Property(e => e.Dlocation)
                    .HasColumnName("dlocation")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Dname)
                    .HasColumnName("dname")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Employee>(entity =>
            {
                entity.HasKey(e => e.Eid)
                    .HasName("PK__employee__D9509F6DAD23511B");

                entity.ToTable("employee");

                entity.Property(e => e.Eid)
                    .HasColumnName("eid")
                    .ValueGeneratedNever();

                entity.Property(e => e.Did).HasColumnName("did");

                entity.Property(e => e.Edesig)
                    .HasColumnName("edesig")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Ename)
                    .HasColumnName("ename")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Esal)
                    .HasColumnName("esal")
                    .HasColumnType("money");

                entity.HasOne(d => d.D)
                    .WithMany(p => p.Employee)
                    .HasForeignKey(d => d.Did)
                    .HasConstraintName("FK__employee__did__3F466844");
            });

            modelBuilder.Entity<Person>(entity =>
            {
                entity.HasKey(e => e.Pid)
                    .HasName("PK__person__DD37D91A73FD7672");

                entity.ToTable("person");

                entity.Property(e => e.Pid)
                    .HasColumnName("pid")
                    .ValueGeneratedNever();

                entity.Property(e => e.Age).HasColumnName("age");

                entity.Property(e => e.PGender)
                    .HasColumnName("p_gender")
                    .HasMaxLength(10)
                    .IsUnicode(false);

                entity.Property(e => e.Pname)
                    .HasColumnName("pname")
                    .HasMaxLength(40)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<RegDet>(entity =>
            {
                entity.HasKey(e => e.Rid)
                    .HasName("PK__RegDet__C2B7EDE85075595B");

                entity.Property(e => e.Rid)
                    .HasColumnName("rid")
                    .ValueGeneratedNever();

                entity.Property(e => e.Contactno).HasColumnName("contactno");

                entity.Property(e => e.Experience)
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Firstname)
                    .HasColumnName("firstname")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Mailid)
                    .HasColumnName("mailid")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Skillset)
                    .HasColumnName("skillset")
                    .HasMaxLength(40)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Staffdet>(entity =>
            {
                entity.HasKey(e => e.Sfid)
                    .HasName("PK__staffdet__2D48894A82D2A362");

                entity.ToTable("staffdet");

                entity.Property(e => e.Sfid)
                    .HasColumnName("sfid")
                    .ValueGeneratedNever();

                entity.Property(e => e.Scontactno).HasColumnName("scontactno");

                entity.Property(e => e.Smailid)
                    .HasColumnName("smailid")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Sname)
                    .HasColumnName("sname")
                    .HasMaxLength(30)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Student>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("student");

                entity.Property(e => e.Feeamount)
                    .HasColumnName("feeamount")
                    .HasColumnType("money");

                entity.Property(e => e.Stmailid)
                    .HasColumnName("stmailid")
                    .HasMaxLength(50)
                    .IsUnicode(false);

                entity.Property(e => e.Stname)
                    .HasColumnName("stname")
                    .HasMaxLength(30)
                    .IsUnicode(false);

                entity.Property(e => e.Strollno).HasColumnName("strollno");
            });

            modelBuilder.Entity<Studentdet>(entity =>
            {
                entity.HasKey(e => e.Stid)
                    .HasName("PK__Studentd__312D1FC72650E3E0");

                entity.Property(e => e.Stid)
                    .HasColumnName("stid")
                    .ValueGeneratedNever();

                entity.Property(e => e.Cid).HasColumnName("cid");

                entity.Property(e => e.Saddr)
                    .HasColumnName("saddr")
                    .HasMaxLength(80)
                    .IsUnicode(false);

                entity.Property(e => e.Sanme)
                    .HasColumnName("sanme")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.Property(e => e.Smailid)
                    .HasColumnName("smailid")
                    .HasMaxLength(40)
                    .IsUnicode(false);

                entity.HasOne(d => d.C)
                    .WithMany(p => p.Studentdet)
                    .HasForeignKey(d => d.Cid)
                    .HasConstraintName("FK__Studentdet__cid__440B1D61");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
