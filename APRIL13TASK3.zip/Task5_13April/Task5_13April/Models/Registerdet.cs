﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Task5_13April.Models
{
    public class Registerdet
    {
    }
}
