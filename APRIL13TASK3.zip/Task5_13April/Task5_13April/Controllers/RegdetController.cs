﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Task5_13April.Models;
using Task5_13April.Repository;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Task5_13April.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegdetController : ControllerBase
    {
        private IRegdet _rd;

        public RegdetController(IRegdet rd)//Dependency Inject
        {
            _rd = rd;
        }
        // GET: api/<RegdetController>
        [HttpGet]
        public async Task<IEnumerable<RegDet>> GetRegdet()
        {
            return await _rd.GetAllRegdet();
        }

        // GET api/<RegdetController>/5
        [HttpGet("{rid}")]
        public async Task<ActionResult<RegDet>> GetRegdet(int rid)
        {
            return await _rd.GetRegdet(rid);
        }

        // POST api/<RegdetController>
        [HttpPost]
        public async Task<ActionResult<RegDet>> PostRegdet([FromBody] RegDet Robj)
        {
            var newregdet = await _rd.InsertRegdet(Robj);
            return CreatedAtAction(nameof(GetRegdet), new { rid = newregdet.Rid }, newregdet);
        }

        // PUT api/<RegdetController>/5
        [HttpPut]
        public async Task<ActionResult<RegDet>> updateRegdet(int rid,[FromBody] RegDet Robj)
        {
            if (rid!= Robj.Rid)
            {
                return BadRequest();
            }
            await _rd.UpdateRegdet(Robj);
            return NoContent();
        }

        // DELETE api/<RegdetController>/5
        [HttpDelete]
        public async Task<ActionResult> deleteRegdet(int rid)
        {
            var res = await _rd.GetRegdet(rid);
            if (res == null)
            {
                return NoContent();
            }
            await _rd.DeleteRegdet(rid);
            return NoContent();
        }
    }
}
