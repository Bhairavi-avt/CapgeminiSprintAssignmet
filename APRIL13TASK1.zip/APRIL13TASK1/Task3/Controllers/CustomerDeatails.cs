﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using APRIL13TASK1.Models;

namespace APRIL13TASK1.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerDeatails : ControllerBase
    {
        List<Customer> clist = new List<Customer>()
        {
            new Customer() {cid = 1,cname="Evans",caddr = "Maharashtra",contactno= 9876540231, cmailaddr="evans@gmail.com"},
            new Customer() {cid = 2,cname="Anna",caddr = "Maharashtra",contactno= 98765407541, cmailaddr="anna@gmail.com"},
            new Customer() {cid = 3,cname="Vivian",caddr = "Maharashtra",contactno= 987653214231, cmailaddr="vivian@gmail.com"},
            new Customer() {cid = 4,cname="Gabriel",caddr = "Maharashtra",contactno= 9879840231, cmailaddr="gabriel@gmail.com"},
            new Customer() {cid = 5,cname="Emily",caddr = "Maharashtra",contactno= 98876540231, cmailaddr="emily@gmail.com"},
        };
        [HttpGet]
        public IEnumerable<Customer> Getall()
        {
            var query1 = from i in clist select i;
            return query1;
        }
    }
}
